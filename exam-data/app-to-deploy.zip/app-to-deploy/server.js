const express = require('express');
const app = express();

const port = process.env.PORT || 3000;

app.post('/', function (req, res) {
  res.send('Bonjour !');
});

app.post('/text', function (req, res) {
  res.send('test');
});

app.post('/test', function (req, res) {
  res.send('text');
});

app.post('/tester', function (req, res) {
  res.send('ceci est un test');
});

app.post('/texte', function (req, res) {
  res.send('ceci est un texte');
});

app.listen(port, function () {
  console.log(`Listening on port ${port}...`);
});
